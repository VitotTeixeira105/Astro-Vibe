<?php
$signo = [
    'nome' => 'Libra',
    'imagens' => [
        'fundo' => 'libraFundo.webp',
        'logo' => 'libraLogo.webp'
    ],
    'descricao' => [
        'geral' => 'Libra é o sétimo signo do zodíaco, representado pelo elemento Ar e regido por Vênus. Este signo simboliza equilíbrio, harmonia e a busca pela justiça e pela beleza.',
        'personalidade' => 'Os librianos são conhecidos por sua diplomacia, sociabilidade e capacidade de ver os dois lados de uma situação. Eles buscam harmonia nas relações e têm um grande apreço pela estética e pelas artes.',
        'caracteristicas' => 'Librianos são charmosos, inteligentes e equilibrados, mas podem ser vistos como indecisos, evasivos ou excessivamente preocupados com a opinião dos outros.'
    ],
    'cores' => [
        'cor1' => [
            'nome' => 'Azul-claro',
            'significado' => 'Tranquilidade, Harmonia, Serenidade e Paz'
        ],
        'cor2' => [
            'nome' => 'Rosa',
            'significado' => 'Amor, Beleza, Sensibilidade e Afeto'
        ],
        'cor3' => [
            'nome' => 'Verde',
            'significado' => 'Equilíbrio, Crescimento, Esperança e Renovação'
        ]
    ],
    'historico' => 'Libra é associado ao outono no hemisfério norte, simbolizando o equilíbrio entre o dia e a noite, e é visto como o ponto de transição entre as estações, refletindo o desejo de estabilidade e harmonia.',
    'mitologia' => [
        'descricao' => '
        Na mitologia grega, Libra está associada à deusa da justiça, Themis, que segurava uma balança para pesar os atos dos mortais. As balanças representam a busca por justiça e a necessidade de equilíbrio nas ações e relações. 
        O signo de Libra reflete essa busca constante por harmonia e o desejo de resolver conflitos de forma justa e equitativa.'
    ]
];




?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <!--FONTES DE LETRAS EXTERNAS - GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!--FONTES DE SIMBOLOS EXTERNAS - PICTOGRAMMERS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="estilosPaginasSignos.css">
    <title>Astro Vibe - <?= $signo['nome'] ?></title>
    <style>
        .wallpaperInicio {
            background-image: url('<?= $signo['imagens']['fundo'] ?>');
        }
    </style>
</head>

<body>
    <div id="div-header"></div>

    <div class="wallpaperInicio"></div>

    <div class="div-title-site">
        <h1><?= $signo['nome'] ?></h1>
    </div>

    <div class="signoDescricaoFer">
        <div class="image-container">
            <img src="<?= $signo['imagens']['logo'] ?>" alt="Logo do signo <?= $signo['nome'] ?>">
        </div>
        <div class="text-container">
            <p><?= $signo['descricao']['geral'] ?></p>
            <p><?= $signo['descricao']['personalidade'] ?></p>
            <p><?= $signo['descricao']['caracteristicas'] ?></p>
        </div>
    </div>

    <table>
        <tr>
            <td>
                <h2>Cores</h2>
                <br>
            </td>
            <td>
                <h2>Histórico</h2>
                <br>
            </td>
        </tr>
        <tr>
            <td>
                <?php
                echo '<p>';
                echo '<b>' . $signo['cores']['cor1']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] . '<br><br>';
                echo '<b>' . $signo['cores']['cor2']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] .  '<br><br>';
                echo '<b>' . $signo['cores']['cor3']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'];
                echo '</p>';
                ?>
            </td>
            <td>
                <p><?= $signo['historico'] ?></p>
            </td>
        </tr>
    </table>

    <div class="div-title-site">
        <h3>Mitologia</h3>
    </div>

    <div class="signoDescricaoFer">
        <p><?= $signo['mitologia']['descricao'] ?></p>

    </div>

    <div id="rodape"></div>
</body>
<script src="script.js"></script>
<script src="scriptRodape.js"></script>
<script src="scriptHeader.js"></script>

</html>