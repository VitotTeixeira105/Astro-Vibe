<!DOCTYPE html>
<html lang="en">

<head>
    <!--FONTES DE LETRAS EXTERNAS - GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!--FONTES DE SIMBOLOS EXTERNAS - PICTOGRAMMERS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bosignos.css">
    <title>Astro Vibe - Signos</title>
</head>
<style>
    .wallpaperInicio {
        background-image: url(wallpapersignoszodiaco2.jpg);
    }

    .imagemSignoBox {
        width: 100px;
        height: 100px;
        background-size: cover;
        background-position: center;
        margin: 0 auto 16px;
        border-radius: 50%;
    }

    .divSigno {
        height: fit-content;
    }

    .descubraMais {
        border-radius: 20px;
        background-color: #6A0DAD;
        color: white;
        padding: 15px;
        font-size: 15px;
        border: none;
    }

    /* Container principal do formulário */
    .formulario {
        border-top: 10px solid #6A0DAD;
        font-family: 'Lato', sans-serif;
        background-color: #4a91e219;
        border-radius: 10px;
        width: 100%;
        padding: 35px;
        margin-bottom: 25px;
    }

    /* Título do formulário */
    .formulario-title h1 {
        text-align: center;
        color: whitesmoke;
        font-size: 28px;
        margin-bottom: 20px;
    }

    .formulario-content div {
        margin-bottom: 15px;
    }

    label {
        font-size: 16px;
        color: whid;
        margin-top: 20px;
        margin-bottom: 10px;
        display: block;
    }

    input {
        padding: 10px;
        width: 98.5%;
        border-radius: 8px;
        border: 1px solid #ddd;
        font-size: 14px;
        color: #555;
        background-color: #f4f4f4;
    }

    .submit-data {
        display: flex;
        justify-content: center;
    }

    button {
        margin-top: 35px;
        padding: 12px 25px;
        font-size: 16px;
        background-color: #3498db;
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
    }

    #response-image {
        height: 500px;
        width: 500px;
        background-size: cover;
        background-position: center;
    }
    .response-button {
        width: 100%;
        text-align: center;
    }

    .response-button button {
        width: 100%;
        height: 100px;
    }
</style>

<body>
    <div id="div-header"></div>

    <div class="wallpaperInicio"></div>

    <div class="div-title-site">
        <h1>Signos</h1>
    </div>

    <div class="introducao divInformacao">
        <div>
            <p>Os signos do zodíaco são um sistema astrológico baseado na divisão da eclíptica, o trajeto aparente do Sol ao longo do ano, em doze partes iguais. Cada uma dessas partes corresponde a uma constelação, formando o que é conhecido como o zodíaco. Este sistema tem raízes profundas na antiga Babilónia e foi desenvolvido ao longo dos séculos por diferentes culturas, incluindo os gregos e romanos, que moldaram o sistema que conhecemos hoje.</p>
            <br>
            <p>A astrologia utiliza os signos do zodíaco como uma forma de interpretar as influências cósmicas sobre a personalidade e a vida das pessoas. Segundo a tradição astrológica, a posição dos planetas no momento do nascimento de uma pessoa pode influenciar aspetos importantes da sua personalidade, emoções e até mesmo das suas tendências e desafios. Assim, os signos funcionam como arquétipos, ou perfis simbólicos, que representam diferentes traços, atitudes e formas de interação com o mundo.</p>
            <br>
            <p>O estudo dos signos envolve também a interpretação dos chamados "elementos" (Fogo, Terra, Ar e Água) e das "modalidades" (Cardinal, Fixo e Mutável), que conferem características adicionais aos signos. Os elementos refletem a forma como cada signo expressa a sua energia: o Fogo é dinâmico e impulsivo, a Terra é prática e materialista, o Ar é intelectual e comunicativo, e a Água é emocional e intuitiva. Já as modalidades indicam como cada signo lida com as mudanças e a estabilidade: os signos cardinais iniciam ciclos, os fixos mantêm a estabilidade, e os mutáveis adaptam-se com facilidade.</p>
            <br>
            <p>Na prática, os signos do zodíaco são utilizados para ajudar as pessoas a compreenderem-se melhor, oferecendo uma espécie de "mapa" das suas características pessoais e potenciais de desenvolvimento. Para muitos, a astrologia oferece uma ferramenta de auto-reflexão e orientação, permitindo entender como responder a situações desafiantes ou como potenciar os seus talentos naturais. Além disso, é comum que as pessoas procurem os signos para analisar compatibilidades em relações, tendências profissionais e, até, influências energéticas ao longo do ano.</p>
            <br>
            <p>É importante notar que a astrologia não é uma ciência, e a sua eficácia e validade são objeto de debate. Para muitos, contudo, ela tem valor simbólico e psicológico, proporcionando uma linguagem para compreender o comportamento humano e as dinâmicas emocionais. Ao explorar os signos do zodíaco, os indivíduos podem ganhar uma maior compreensão de si mesmos e do mundo ao seu redor, promovendo uma visão mais introspectiva e ponderada das suas ações e escolhas.</p>
            <br>
         </div>
    </div>



    
    <div style="display: flex; justify-content:center;">
        <div class="x formulario">
            <div class="formulario-title">
                <h1>Descubra Mais Sobre Você</h1>
            </div>
            <div class="formulario-content">


                <div class="datanascimento-data">
                    <label for="dia-nascimento">Dia</label>
                    <input id="dia-nascimento" name="dia-nascimento">
                    <label for="mes-nascimento">Mes</label>
                    <input id="mes-nascimento" name="mes-nascimento">
                    <label for="ano-nascimento">Ano</label>
                    <input id="ano-nascimento" name="ano-nascimento">
                </div>

                <div class="submit-data">
                    <button type="button" onclick="mostrarData()">Clique Aqui</button>
                </div>
            </div>
        </div>
    </div>
    <div style="display: flex; justify-content:center; margin-bottom:125px;">
        <div class="x formulario" >
            <div class="formulario-title">
                <h1>Os Seus Resultados</h1>
            </div>
            <div class="formulario-content" style="display: flex;">
                
                <div class="response-text" style="width: 50%; text-align:justify; margin-right:15px;">
                    <h2 style="text-align:center;">Se você nasceu em: <span id="rascunho">N/A</span></h2>
                    <p id="tosta"></p>
                </div>
                
                <div id="response-image"></div>
                
                
                
            </div>
            <div style="width: 100%;" id="response-container"></div>
        </div>
    </div>

    <div class="boxSignosWrapper">
        <?php
            $signosZodiaco = array(
                array('start' => '03-21', 'end' => '04-19', 'nome' => 'Áries', 'nomeBox' => 'boxaries', 'planeta' => 'Marte', 'elemento' => 'Fogo', 'image' => 'ariesLogo.webp', 'qualidade' => 'Cardinal', 'mesComeca' => '21 / Março', 'mesAcaba' => '20 / Abril', 'pagina' => 'aries.php'),
                array('start' => '04-20', 'end' => '05-20', 'nome' => 'Touro', 'nomeBox' => 'boxtouro', 'planeta' => 'Vênus', 'elemento' => 'Terra', 'image' => 'touroLogo.webp', 'qualidade' => 'Fixo', 'mesComeca' => '21 / Abril', 'mesAcaba' => '20 / Maio', 'pagina' => 'touro.php'),
                array('start' => '05-21', 'end' => '06-20', 'nome' => 'Gêmeos', 'nomeBox' => 'boxgemeos', 'planeta' => 'Mercúrio', 'elemento' => 'Ar', 'image' => 'gemeosLogo.webp', 'qualidade' => 'Mutável', 'mesComeca' => '21 / Maio', 'mesAcaba' => '20 / Junho', 'pagina' => 'gemeos.php'),
                array('start' => '06-21', 'end' => '07-22', 'nome' => 'Câncer', 'nomeBox' => 'boxcancer', 'planeta' => 'Lua', 'elemento' => 'Água', 'image' => 'cancerLogo.webp', 'qualidade' => 'Cardinal', 'mesComeca' => '21 / Junho', 'mesAcaba' => '21 / Julho', 'pagina' => 'cancer.php'),
                array('start' => '07-23', 'end' => '08-22', 'nome' => 'Leão', 'nomeBox' => 'boxleao', 'planeta' => 'Sol', 'elemento' => 'Fogo', 'image' => 'leaoLogo.webp', 'qualidade' => 'Fixo', 'mesComeca' => '22 / Julho', 'mesAcaba' => '22 / Agosto', 'pagina' => 'leao.php'),
                array('start' => '08-23', 'end' => '09-22', 'nome' => 'Virgem', 'nomeBox' => 'boxvirgem', 'planeta' => 'Mercúrio', 'elemento' => 'Terra', 'image' => 'virgemLogo.webp', 'qualidade' => 'Mutável', 'mesComeca' => '23 / Agosto', 'mesAcaba' => '22 / Setembro', 'pagina' => 'virgem.php'),
                array('start' => '09-23', 'end' => '10-22', 'nome' => 'Libra', 'nomeBox' => 'boxlibra', 'planeta' => 'Vênus', 'elemento' => 'Terra', 'image' => 'libraLogo.webp', 'qualidade' => 'Cardinal', 'mesComeca' => '23 / Setembro', 'mesAcaba' => '22 / Outubro', 'pagina' => 'libra.php'),
                array('start' => '10-23', 'end' => '11-21', 'nome' => 'Escorpião', 'nomeBox' => 'boxescorpiao', 'planeta' => 'Plutão', 'elemento' => 'Água', 'image' => 'escorpiaoLogo.webp', 'qualidade' => 'Fixo', 'mesComeca' => '23 / Outubro', 'mesAcaba' => '21 / Novembro', 'pagina' => 'escorpiao.php'),
                array('start' => '11-22', 'end' => '12-21', 'nome' => 'Sagitário', 'nomeBox' => 'boxsagitario', 'planeta' => 'Júpiter', 'elemento' => 'Fogo', 'image' => 'sagitarioLogo.webp', 'qualidade' => 'Mutável', 'mesComeca' => '22 / Novembro', 'mesAcaba' => '21 / Dezembro', 'pagina' => 'sagitario.php'),
                array('start' => '12-22', 'end' => '01-19', 'nome' => 'Capricórnio', 'nomeBox' => 'boxcapricornio', 'planeta' => 'Saturno', 'elemento' => 'Terra', 'image' => 'capricornioLogo.webp', 'qualidade' => 'Cardinal', 'mesComeca' => '22 / Dezembro', 'mesAcaba' => '20 / Janeiro', 'pagina' => 'capricornio.php'),
                array('start' => '01-20', 'end' => '02-18', 'nome' => 'Aquário', 'nomeBox' => 'boxaquario', 'planeta' => 'Urano', 'elemento' => 'Ar', 'image' => 'aquarioLogo.webp', 'qualidade' => 'Fixo', 'mesComeca' => '21 / Janeiro', 'mesAcaba' => '19 / Fevereiro', 'pagina' => 'aquario.php'),
                array('start' => '02-19', 'end' => '03-20', 'nome' => 'Peixes', 'nomeBox' => 'boxpeixes', 'planeta' => 'Neptuno', 'elemento' => 'Água', 'image' => 'peixesLogo.webp', 'qualidade' => 'Mutável', 'mesComeca' => '20 / Fevereiro', 'mesAcaba' => '20 / Março', 'pagina' => 'peixes.php')
            );
        
            $contador = 0;
            $totalSignos = 12;
        
            while ($contador < $totalSignos) {
        
                if ($contador % 3 == 0) {
                    echo '<div class="boxSignos">';
                }

                $detalhesSigno = $signosZodiaco[$contador];
        
                echo '<div class="divSigno ' . $detalhesSigno['nomeBox'] . '">';
                echo '<div class="imagemSignoBox" style="background-image: url(' . $detalhesSigno['image'] . ');"></div>';
                echo '<div class="descriptionSigno">';
                echo '<div class="descriptionSignoTitle">';
                echo '<h2>' . $detalhesSigno['nome'] . '</h2>';
                echo '</div>';
                echo '<div class="informationSignoBox">';
                echo '<div><p><b>Planeta: </b>' . $detalhesSigno['planeta'] . '</p></div>';
                echo '<div><p><b>Elemento: </b>' . $detalhesSigno['elemento'] . '</p></div>';
                echo '<div><p><b>Qualidade: </b>' . $detalhesSigno['qualidade'] . '</p></div>';
                echo '<div><p><b>Meses: </b>' . $detalhesSigno['mesComeca'] . ' - ' . $detalhesSigno['mesAcaba'] . '</p></div>';
                echo '<br><div><a href="' . $detalhesSigno['pagina'] . '"><button class="descubraMais">Descubra Mais</button></a></div><br>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
        
                $contador++;
        
                if ($contador % 3 == 0 || $contador == $totalSignos) {
                    echo '</div>';
                }
            }
        ?>
    
    </div>
    <div id="rodape"></div>
</body>
<script>
    const ariesDescricao = "<p>Áries é o primeiro signo do zodíaco, representado pelo elemento Fogo e regido por Marte. Este signo simboliza coragem, iniciativa e energia vital, sendo conhecido por sua atitude determinada e espírito competitivo. Os arianos são líderes naturais, movidos por um desejo inato de enfrentar desafios e conquistar novos territórios.</p> <p>Com uma personalidade dinâmica e cheia de entusiasmo, os nativos de Áries possuem uma abordagem direta e assertiva em tudo o que fazem. São espontâneos e cheios de energia, prontos para começar projetos e inspirar os outros com sua determinação. Apesar de sua impaciência, eles são conhecidos por sua sinceridade e paixão em alcançar objetivos.</p> <p>Impulsivos e aventureiros, os arianos têm uma natureza pioneira que os leva a explorar o desconhecido. Sua coragem e determinação os tornam exemplos de força, enquanto sua energia ardente e entusiasmo contagiante os destacam em qualquer situação.</p>";
    const touroDescricao = "<p>Touro é o segundo signo do zodíaco, representado pelo elemento Terra e regido por Vênus. Este signo simboliza estabilidade, sensualidade e uma conexão profunda com os prazeres da vida. Taurinos são conhecidos por sua determinação inabalável e por valorizarem conforto, beleza e segurança.</p> <p>Com uma personalidade prática e confiável, os nativos de Touro apreciam as coisas simples e duradouras da vida. São trabalhadores persistentes, com uma capacidade única de transformar ideias em realizações concretas. Apesar de sua teimosia, eles são leais e dedicados às pessoas e causas que amam.</p> <p>Amantes da arte e da natureza, os taurinos possuem um senso estético apurado e uma afinidade por experiências sensoriais. Sua paciência e confiabilidade os tornam amigos e parceiros excepcionais, sempre prontos para construir relações sólidas e sustentáveis.</p>";
    const gemeosDescricao = "<p>Gêmeos é o terceiro signo do zodíaco, representado pelo elemento Ar e regido por Mercúrio. Este signo simboliza comunicação, curiosidade e adaptabilidade, sendo conhecido por sua mente ágil e personalidade versátil. Geminianos são exploradores natos, movidos por uma sede insaciável de conhecimento e conexão.</p> <p>Com uma personalidade inteligente e comunicativa, os nativos de Gêmeos possuem uma habilidade notável de se expressar e interagir com os outros. São conhecidos por sua capacidade de se adaptar rapidamente a novas situações e por seu encanto natural em conversas. Embora possam parecer indecisos, sua flexibilidade é sua maior força.</p> <p>Curiosos e sociáveis, os geminianos são eternos aprendizes, sempre prontos para compartilhar ideias e explorar novas perspectivas. Sua energia vibrante e natureza inquisitiva os tornam inspiradores, capazes de trazer leveza e diversão para qualquer ambiente.</p>";
    const cancerDescricao = "<p>Câncer é o quarto signo do zodíaco, representado pelo elemento Água e regido pela Lua. Este signo simboliza emoções, intuição e cuidado, sendo conhecido por sua natureza protetora e profundamente ligada à família. Cancerianos têm uma capacidade única de conectar-se emocionalmente com os outros e de oferecer apoio incondicional.</p> <p>Com uma personalidade sensível e empática, os nativos de Câncer são altamente intuitivos e capazes de perceber as necessidades dos outros com facilidade. São leais e dedicados, sempre dispostos a fazer sacrifícios para proteger aqueles que amam. Embora possam ser reservados, sua vulnerabilidade é uma parte importante de sua humanidade.</p> <p>Família e lar são de extrema importância para os cancerianos, que buscam criar um ambiente seguro e acolhedor para si mesmos e para os outros. Sua natureza carinhosa e cuidadosa os torna amigos, pais e parceiros excepcionais.</p>";
    const leaoDescricao = "<p>Leão é o quinto signo do zodíaco, representado pelo elemento Fogo e regido pelo Sol. Este signo simboliza liderança, criatividade e autoexpressão, sendo conhecido por sua presença magnética e espírito generoso. Leoninos são natural líderes, movidos por um desejo profundo de se destacar e deixar sua marca no mundo.</p> <p>Com uma personalidade radiante e confiante, os nativos de Leão têm uma energia contagiante e um senso de dignidade que atrai a atenção onde quer que vão. São criativos e apaixonados, com uma grande capacidade de inspirar os outros e conquistar seus corações. Embora possam ser teimosos, sua generosidade e coragem os tornam inconfundíveis.</p> <p>Os leoninos adoram ser admirados e reconhecidos por suas habilidades e realizações. Sua natureza carinhosa e calorosa os torna grandes amigos e companheiros, sempre prontos para apoiar aqueles que amam.</p>";
    const virgemDescricao = "<p>Virgem é o sexto signo do zodíaco, representado pelo elemento Terra e regido por Mercúrio. Este signo simboliza organização, praticidade e atenção aos detalhes. Virginianos são conhecidos por sua abordagem meticulosa da vida e sua busca constante pela perfeição.</p> <p>Com uma personalidade analítica e crítica, os nativos de Virgem são altamente eficientes e focados na realização de tarefas de maneira organizada. São perfeccionistas e têm um talento natural para perceber detalhes que os outros podem ignorar. Embora possam ser excessivamente exigentes, sua dedicação ao trabalho e à melhoria contínua é admirável.</p> <p>Virginianos são pessoas muito práticas, que buscam sempre a solução mais racional para os problemas. Sua preocupação com o bem-estar dos outros e sua atenção ao cuidado fazem deles amigos e parceiros leais.</p>";
    const libraDescricao = "<p>Libra é o sétimo signo do zodíaco, representado pelo elemento Ar e regido por Vênus. Este signo simboliza equilíbrio, harmonia e justiça, sendo conhecido por sua capacidade de ver diferentes perspectivas e buscar a paz nas situações.</p> <p>Com uma personalidade diplomática e charmosa, os nativos de Libra são excelentes em mediar conflitos e criar ambientes harmoniosos. São sociáveis, adoram se relacionar com os outros e têm um grande senso estético. Embora possam ser indecisos em momentos de escolha, sua habilidade de pensar de forma justa e equilibrada é sua maior força.</p> <p>Librianos são apaixonados pela busca da beleza e da harmonia nas relações. Sua habilidade de equilibrar as necessidades dos outros com as suas próprias os torna excelentes parceiros, amigos e conselheiros.</p>";
    const escorpiaoDescricao = "<p>Escorpião é o oitavo signo do zodíaco, representado pelo elemento Água e regido por Plutão. Este signo simboliza intensidade, transformação e mistério, sendo conhecido por sua natureza profunda e apaixonada.</p> <p>Com uma personalidade intensa e focada, os nativos de Escorpião têm uma presença magnética e uma habilidade única de se conectar com os outros em níveis profundos. São determinados e têm uma grande força emocional, embora possam ser reservados e misteriosos. Sua lealdade é inabalável, mas sua natureza protetora pode fazer com que guardem segredos.</p> <p>Escorpianos são pessoas profundamente apaixonadas que buscam transformar tudo ao seu redor. Sua capacidade de se reinventar constantemente e sua coragem em enfrentar desafios os tornam figuras poderosas e influentes.</p>";
    const sagitarioDescricao = "<p>Sagitário é o nono signo do zodíaco, representado pelo elemento Fogo e regido por Júpiter. Este signo simboliza aventura, liberdade e otimismo, sendo conhecido por sua natureza exploradora e seu desejo de expandir os horizontes.</p> <p>Com uma personalidade expansiva e entusiasta, os nativos de Sagitário estão sempre em busca de novas experiências e conhecimentos. São otimistas e inspiradores, capazes de contagiar os outros com sua energia positiva. Embora possam ser impulsivos e inquietos, sua visão positiva da vida e seu espírito livre são cativantes.</p> <p>Sagitarianos adoram explorar o mundo e aprender sobre culturas e ideias diferentes. Sua busca constante por aventura e crescimento os torna companheiros animados e dedicados.</p>";
    const capricornioDescricao = "<p>Capricórnio é o décimo signo do zodíaco, representado pelo elemento Terra e regido por Saturno. Este signo simboliza responsabilidade, ambição e perseverança, sendo conhecido por sua abordagem prática e determinada em relação à vida.</p> <p>Com uma personalidade séria e focada, os nativos de Capricórnio têm uma enorme capacidade de trabalho e uma forte ética. São realistas e têm uma visão estratégica da vida, buscando sempre alcançar seus objetivos através da disciplina e do esforço. Embora possam ser reservados, sua dedicação e responsabilidade os tornam figuras confiáveis.</p> <p>Capricornianos são altamente ambiciosos e determinados a alcançar sucesso. Sua habilidade de planejar e perseverar diante das dificuldades os torna exemplos de trabalho árduo e resiliência.</p>";
    const aquarioDescricao = "<p>Aquário é o décimo primeiro signo do zodíaco, representado pelo elemento Ar e regido por Urano. Este signo simboliza inovação, originalidade e humanitarismo, sendo conhecido por sua mente aberta e visão futurista.</p> <p>Com uma personalidade independente e visionária, os nativos de Aquário são os pensadores do zodíaco. Eles têm uma visão única do mundo e buscam constantemente maneiras de melhorar a sociedade. Embora possam ser excêntricos e imprevisíveis, sua originalidade e capacidade de pensar fora da caixa os tornam líderes no pensamento inovador.</p> <p>Aquarianos se dedicam a causas sociais e humanitárias, buscando sempre promover mudanças significativas. Sua paixão por inovação e sua capacidade de abraçar a diversidade os tornam inspiradores e cativantes.</p>";
    const peixesDescricao = "<p>Peixes é o décimo segundo signo do zodíaco, representado pelo elemento Água e regido por Netuno. Este signo simboliza empatia, intuição e espiritualidade, sendo conhecido por sua sensibilidade e conexão com o mundo emocional.</p> <p>Com uma personalidade sonhadora e compassiva, os nativos de Peixes são profundamente intuitivos e sensíveis às emoções dos outros. São muito empáticos, sempre dispostos a ajudar e a oferecer apoio. Embora possam ser escapistas em momentos de dificuldades, sua natureza gentil e compreensiva os torna companheiros valiosos.</p> <p>Piscianos são pessoas espirituais e criativas, frequentemente buscando expressão artística e conexão com dimensões mais profundas da vida. Sua capacidade de se conectar emocionalmente com os outros os torna amigos e parceiros excepcionais.</p>";
    const ariesImage = 'ariesLogo.webp';
    const touroImage = 'touroLogo.webp';
    const gemeosImage = 'gemeosLogo.webp';
    const cancerImage = 'cancerLogo.webp';
    const leaoImage = 'leaoLogo.webp';
    const virgemImage = 'virgemLogo.webp';
    const libraImage = 'libraLogo.webp';
    const escorpiaoImage = 'escorpiaoLogo.webp';
    const sagitarioImage = 'sagitarioLogo.webp';
    const capricornioImage = 'capricornioLogo.webp';
    const aquarioImage = 'aquarioLogo.webp';
    const peixesImage = 'peixesLogo.webp';
    const ariesLink = 'aries.php';
    const touroLink = 'touro.php';
    const gemeosLink = 'gemeos.php';
    const cancerLink = 'cancer.php';
    const leaoLink = 'leao.php';
    const virgemLink = 'virgem.php';
    const libraLink = 'libra.php';
    const escorpiaoLink = 'escorpiao.php';
    const sagitarioLink = 'sagitario.php';
    const capricornioLink = 'capricornio.php';
    const aquarioLink = 'aquario.php';
    const peixesLink = 'peixes.php';

    function mostrarData() {
        var diaNascimento = parseInt(document.getElementById("dia-nascimento").value);                                      
        var mesNascimento = parseInt(document.getElementById("mes-nascimento").value);                                      
        var anoNascimento = parseInt(document.getElementById("ano-nascimento").value);                                      
        var caixaTextoRascunho = document.getElementById("rascunho");
        var caixaTextoDescricao = document.getElementById("tosta");
        var caixaButton = document.getElementById("response-container");
        var caixaImagemSigno = document.getElementById("response-image");
        caixaTextoRascunho.innerHTML = diaNascimento + ' / ' + mesNascimento + ' / ' + anoNascimento;
        
        var signoEntao;
        var signoLogo;
        var signoLink;

        if ((mesNascimento === 3 && diaNascimento >= 21) || (mesNascimento === 4 && diaNascimento <= 19)) {
            signoEntao = ariesDescricao;
            signoLogo = 'ariesLogo.webp';
            signoLink = ariesLink;
        } else if ((mesNascimento === 4 && diaNascimento >= 20) || (mesNascimento === 5 && diaNascimento <= 20)) {
            signoEntao = touroDescricao;
            signoLogo = 'touroLogo.webp';
            signoLink = touroLink;
        } else if ((mesNascimento === 5 && diaNascimento >= 21) || (mesNascimento === 6 && diaNascimento <= 20)) {
            signoEntao = gemeosDescricao;
            signoLogo = 'gemeosLogo.webp';
            signoLink = gemeosLink;
        } else if ((mesNascimento === 6 && diaNascimento >= 21) || (mesNascimento === 7 && diaNascimento <= 22)) {
            signoEntao = cancerDescricao;
            signoLogo = 'cancerLogo.webp';
            signoLink = cancerLink;
        } else if ((mesNascimento === 7 && diaNascimento >= 23) || (mesNascimento === 8 && diaNascimento <= 22)) {
            signoEntao = leaoDescricao;
            signoLogo = 'leaoLogo.webp';
            signoLink = leaoLink;
        } else if ((mesNascimento === 8 && diaNascimento >= 23) || (mesNascimento === 9 && diaNascimento <= 22)) {
            signoEntao = virgemDescricao;
            signoLogo = 'virgemLogo.webp';
            signoLink = virgemLink;
        } else if ((mesNascimento === 9 && diaNascimento >= 23) || (mesNascimento === 10 && diaNascimento <= 22)) {
            signoEntao = libraDescricao;
            signoLogo = 'libraLogo.webp';
            signoLink = libraLink;
        } else if ((mesNascimento === 10 && diaNascimento >= 23) || (mesNascimento === 11 && diaNascimento <= 21)) {
            signoEntao = escorpiaoDescricao;
            signoLogo = 'escorpiaoLogo.webp';
            signoLink = escorpiaoLink;
        } else if ((mesNascimento === 11 && diaNascimento >= 22) || (mesNascimento === 12 && diaNascimento <= 21)) {
            signoEntao = sagitarioDescricao;
            signoLogo = 'sagitarioLogo.webp';
            signoLink = sagitarioLink;
        } else if ((mesNascimento === 12 && diaNascimento >= 22) || (mesNascimento === 1 && diaNascimento <= 19)) {
            signoEntao = capricornioDescricao;
            signoLogo = 'capricornioLogo.webp';
            signoLink = capricornioLink;
        } else if ((mesNascimento === 1 && diaNascimento >= 20) || (mesNascimento === 2 && diaNascimento <= 18)) {
            signoEntao = aquarioDescricao;
            signoLogo = 'aquarioLogo.webp';
            signoLink = aquarioLink;
        } else if ((mesNascimento === 2 && diaNascimento >= 19) || (mesNascimento === 3 && diaNascimento <= 20)) {
            signoEntao = peixesDescricao;
            signoLogo = 'peixesLogo.webp';
            signoLink = peixesLink;
        }

        caixaButton.innerHTML = '<div class="response-button"><a href="' + signoLink + '"><button class="descubraMais">Descubra Mais</button></a></div>';
        caixaTextoDescricao.innerHTML = signoEntao;
        caixaImagemSigno.style.backgroundImage = "url(" + signoLogo + ")";
    }
</script>
<script src="script.js"></script>
<script src="scriptRodape.js"></script>
<script src="scriptHeader.js"></script>

</html>