<?php
$signo = [
    'nome' => 'Áries',
    'imagens' => [
        'fundo' => 'ariesFundo.jpg',
        'logo' => 'ariesLogo.webp'
    ],
    'descricao' => [
        'geral' => 'Áries é o primeiro signo do zodíaco, representado pelo elemento Fogo e regido pelo planeta Marte. Este signo simboliza iniciativa, coragem e a energia necessária para novos começos.',
        'personalidade' => 'Os arianos são conhecidos por sua liderança natural, entusiasmo e atitude assertiva. Eles são determinados, diretos e não têm medo de enfrentar desafios.',
        'caracteristicas' => 'Arianos são ousados, competitivos e apaixonados, mas podem ser impulsivos, impacientes e às vezes temperamentais.'
    ],
    'cores' => [
        'cor1' => [
            'nome' => 'Vermelho',
            'significado' => 'Paixão, Energia, Coragem e Determinação'
        ],
        'cor2' => [
            'nome' => 'Dourado',
            'significado' => 'Sucesso, Força, Nobreza e Brilho'
        ],
        'cor3' => [
            'nome' => 'Branco',
            'significado' => 'Pureza, Inocência, Renovação e Harmonia'
        ]
    ],
    'historico' => 'Áries é considerado o início do ciclo astrológico, associado ao equinócio da primavera no hemisfério norte, um período de novos começos e renovação.',
    'mitologia' => [
        'descricao' => '
        Na mitologia grega, Áries está associado ao carneiro alado Crisômalo, que resgatou Frixo e Hele. Crisômalo tinha lã de ouro e foi enviado por Nefele para salvar seus filhos. Após o resgate, o carneiro foi sacrificado a Zeus, e sua lã de ouro foi guardada em um templo sagrado, inspirando o mito do Velocino de Ouro. 
        Áries também simboliza força e coragem, atributos frequentemente associados a heróis na mitologia.
        '
    ]
];

?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <!--FONTES DE LETRAS EXTERNAS - GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!--FONTES DE SIMBOLOS EXTERNAS - PICTOGRAMMERS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="estilosPaginasSignos.css">
    <title>Astro Vibe - <?= $signo['nome'] ?></title>
    <style>
        .wallpaperInicio {
            background-image: url('<?= $signo['imagens']['fundo'] ?>');
        }
    </style>
</head>

<body>
    <div id="div-header"></div>

    <div class="wallpaperInicio"></div>

    <div class="div-title-site">
        <h1><?= $signo['nome'] ?></h1>
    </div>

    <div class="signoDescricaoFer">
        <div class="image-container">
            <img src="<?= $signo['imagens']['logo'] ?>" alt="Logo do signo <?= $signo['nome'] ?>">
        </div>
        <div class="text-container">
            <p><?= $signo['descricao']['geral'] ?></p>
            <p><?= $signo['descricao']['personalidade'] ?></p>
            <p><?= $signo['descricao']['caracteristicas'] ?></p>
        </div>
    </div>

    <table>
        <tr>
            <td>
                <h2>Cores</h2>
                <br>
            </td>
            <td>
                <h2>Histórico</h2>
                <br>
            </td>
        </tr>
        <tr>
            <td>
                <?php
                echo '<p>';
                echo '<b>' . $signo['cores']['cor1']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] . '<br><br>';
                echo '<b>' . $signo['cores']['cor2']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] .  '<br><br>';
                echo '<b>' . $signo['cores']['cor3']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'];
                echo '</p>';
                ?>
            </td>
            <td>
                <p><?= $signo['historico'] ?></p>
            </td>
        </tr>
    </table>

    <div class="div-title-site">
        <h3>Mitologia</h3>
    </div>

    <div class="signoDescricaoFer">
        <p><?= $signo['mitologia']['descricao'] ?></p>

    </div>

    <div id="rodape"></div>
</body>
<script src="script.js"></script>
<script src="scriptRodape.js"></script>
<script src="scriptHeader.js"></script>

</html>