//FUNÇÃO MUDAR OPACIDADE

function mudarOpacidade(opacidade, idElemento) {
    var elemento = document.getElementById(idElemento);
    if (elemento) {
        elemento.style.opacity = opacidade;
    }
}














