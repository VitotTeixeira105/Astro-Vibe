<?php
$signo = [
    'nome' => 'Peixes',
    'imagens' => [
        'fundo' => 'peixesFundo.webp',
        'logo' => 'peixesLogo.webp'
    ],
    'descricao' => [
        'geral' => 'Peixes é o décimo segundo e último signo do zodíaco, representado pelo elemento Água e regido por Netuno e Júpiter. Este signo simboliza compaixão, imaginação e a busca pela espiritualidade.',
        'personalidade' => 'Os piscianos são conhecidos por sua sensibilidade, empatia e criatividade. São sonhadores, intuitivos e profundamente conectados ao mundo emocional, sendo capazes de compreender as necessidades dos outros de maneira intuitiva.',
        'caracteristicas' => 'Piscianos são gentis, compassivos e artísticos, mas podem ser vistos como escapistas, indecisos ou excessivamente idealistas em algumas situações.'
    ],
    'cores' => [
        'cor1' => [
            'nome' => 'Verde-água',
            'significado' => 'Calma, Harmonia, Cura e Sensibilidade'
        ],
        'cor2' => [
            'nome' => 'Lilás',
            'significado' => 'Espiritualidade, Intuição, Mistério e Transformação'
        ],
        'cor3' => [
            'nome' => 'Azul-claro',
            'significado' => 'Tranquilidade, Paz, Serenidade e Emoção'
        ]
    ],
    'historico' => 'Peixes é associado ao fim do inverno e o início da primavera no hemisfério norte, refletindo a transição e a capacidade de adaptação, além de simbolizar o ciclo de renovação e regeneração.',
    'mitologia' => [
        'descricao' => '
        Na mitologia grega, Peixes está relacionado a Afrodite e seu filho Eros, que se transformaram em peixes para escapar do monstro Tifão. Eles amarraram-se um ao outro com cordas para não se perderem enquanto fugiam. Como recompensa por sua fuga bem-sucedida, os deuses os colocaram entre as estrelas como a constelação de Peixes.
        O signo de Peixes reflete a conexão com o espiritual e o emocional, a sensibilidade à dor do mundo e o desejo de ajudar os outros.'
    ]
];





?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <!--FONTES DE LETRAS EXTERNAS - GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!--FONTES DE SIMBOLOS EXTERNAS - PICTOGRAMMERS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="estilosPaginasSignos.css">
    <title>Astro Vibe - <?= $signo['nome'] ?></title>
    <style>
        .wallpaperInicio {
            background-image: url('<?= $signo['imagens']['fundo'] ?>');
        }
    </style>
</head>

<body>
    <div id="div-header"></div>

    <div class="wallpaperInicio"></div>

    <div class="div-title-site">
        <h1><?= $signo['nome'] ?></h1>
    </div>

    <div class="signoDescricaoFer">
        <div class="image-container">
            <img src="<?= $signo['imagens']['logo'] ?>" alt="Logo do signo <?= $signo['nome'] ?>">
        </div>
        <div class="text-container">
            <p><?= $signo['descricao']['geral'] ?></p>
            <p><?= $signo['descricao']['personalidade'] ?></p>
            <p><?= $signo['descricao']['caracteristicas'] ?></p>
        </div>
    </div>

    <table>
        <tr>
            <td>
                <h2>Cores</h2>
                <br>
            </td>
            <td>
                <h2>Histórico</h2>
                <br>
            </td>
        </tr>
        <tr>
            <td>
                <?php
                echo '<p>';
                echo '<b>' . $signo['cores']['cor1']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] . '<br><br>';
                echo '<b>' . $signo['cores']['cor2']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] .  '<br><br>';
                echo '<b>' . $signo['cores']['cor3']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'];
                echo '</p>';
                ?>
            </td>
            <td>
                <p><?= $signo['historico'] ?></p>
            </td>
        </tr>
    </table>

    <div class="div-title-site">
        <h3>Mitologia</h3>
    </div>

    <div class="signoDescricaoFer">
        <p><?= $signo['mitologia']['descricao'] ?></p>

    </div>

    <div id="rodape"></div>
</body>
<script src="script.js"></script>
<script src="scriptRodape.js"></script>
<script src="scriptHeader.js"></script>

</html>