<?php
$signo = [
    'nome' => 'Câncer',
    'imagens' => [
        'fundo' => 'cancerFundo.webp',
        'logo' => 'cancerLogo.webp'
    ],
    'descricao' => [
        'geral' => 'Câncer é o quarto signo do zodíaco, representado pelo elemento Água e regido pela Lua. Este signo simboliza emoções profundas, intuição e uma forte conexão com o lar e a família.',
        'personalidade' => 'Os cancerianos são conhecidos por sua sensibilidade, empatia e capacidade de nutrir aqueles ao seu redor. Eles têm uma conexão emocional forte e buscam segurança emocional em suas relações.',
        'caracteristicas' => 'Cancerianos são protetores, intuitivos e criativos, mas podem ser vistos como possessivos, inseguros ou excessivamente emocionais em alguns contextos.'
    ],
    'cores' => [
        'cor1' => [
            'nome' => 'Prata',
            'significado' => 'Sensibilidade, Intuição, Feminilidade e Mistério'
        ],
        'cor2' => [
            'nome' => 'Branco',
            'significado' => 'Pureza, Paz, Renovação e Proteção'
        ],
        'cor3' => [
            'nome' => 'Azul-claro',
            'significado' => 'Calma, Serenidade, Harmonia e Clareza Emocional'
        ]
    ],
    'historico' => 'Câncer marca o início do verão no hemisfério norte e é simbolizado pelo caranguejo, representando proteção, força interior e a capacidade de lidar com as emoções.',
    'mitologia' => [
        'descricao' => '
        Na mitologia grega, Câncer está associado ao caranguejo enviado por Hera durante a batalha de Hércules contra a Hidra de Lerna. O caranguejo tentou ajudar a Hidra, mas foi esmagado por Hércules. Como recompensa por sua lealdade, Hera o colocou no céu como uma constelação. 
        O signo de Câncer reflete as características do caranguejo: a habilidade de se proteger e a conexão com as águas emocionais profundas.'
    ]
];


?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <!--FONTES DE LETRAS EXTERNAS - GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!--FONTES DE SIMBOLOS EXTERNAS - PICTOGRAMMERS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="estilosPaginasSignos.css">
    <title>Astro Vibe - <?= $signo['nome'] ?></title>
    <style>
        .wallpaperInicio {
            background-image: url('<?= $signo['imagens']['fundo'] ?>');
        }
    </style>
</head>

<body>
    <div id="div-header"></div>

    <div class="wallpaperInicio"></div>

    <div class="div-title-site">
        <h1><?= $signo['nome'] ?></h1>
    </div>

    <div class="signoDescricaoFer">
        <div class="image-container">
            <img src="<?= $signo['imagens']['logo'] ?>" alt="Logo do signo <?= $signo['nome'] ?>">
        </div>
        <div class="text-container">
            <p><?= $signo['descricao']['geral'] ?></p>
            <p><?= $signo['descricao']['personalidade'] ?></p>
            <p><?= $signo['descricao']['caracteristicas'] ?></p>
        </div>
    </div>

    <table>
        <tr>
            <td>
                <h2>Cores</h2>
                <br>
            </td>
            <td>
                <h2>Histórico</h2>
                <br>
            </td>
        </tr>
        <tr>
            <td>
                <?php
                echo '<p>';
                echo '<b>' . $signo['cores']['cor1']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] . '<br><br>';
                echo '<b>' . $signo['cores']['cor2']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'] .  '<br><br>';
                echo '<b>' . $signo['cores']['cor3']['nome'] . '</b>: ' . $signo['cores']['cor1']['significado'];
                echo '</p>';
                ?>
            </td>
            <td>
                <p><?= $signo['historico'] ?></p>
            </td>
        </tr>
    </table>

    <div class="div-title-site">
        <h3>Mitologia</h3>
    </div>

    <div class="signoDescricaoFer">
        <p><?= $signo['mitologia']['descricao'] ?></p>

    </div>

    <div id="rodape"></div>
</body>
<script src="script.js"></script>
<script src="scriptRodape.js"></script>
<script src="scriptHeader.js"></script>

</html>