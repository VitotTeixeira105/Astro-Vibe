<!DOCTYPE html>
<html lang="pt">

<head>
    <!--FONTES DE LETRAS EXTERNAS - GOOGLE FONTS-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Agdasima:wght@400;700&family=Cinzel:wght@400..900&family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

    <!--FONTES DE SIMBOLOS EXTERNAS - PICTOGRAMMERS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@mdi/font@7.4.47/css/materialdesignicons.min.css">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Mais Sobre Voc - Astro Vibe</title>
</head>
<style>
    ol {

        font-size: 18px;
        color: #EDEDED;
        font-family: 'Lato', sans-serif;

    }

    .wallpaperInicio {
        background-image: url(mapaastralFundo.webp);
    }


    /* Container principal do formulário */
    .formulario {
        font-family: 'Lato', sans-serif;
        background-color: #fff;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        width: 100%;
        padding: 35px;
    }

    /* Título do formulário */
    .formulario-title h1 {
        text-align: center;
        color: #3f3f3f;
        font-size: 28px;
        margin-bottom: 20px;
    }

    .formulario-content div {
        margin-bottom: 15px;
    }

    label {
        font-size: 16px;
        color: #333;
        margin-bottom: 5px;
        display: block;
    }

    input {
        padding: 10px;
        width: 98.5%;
        border-radius: 8px;
        border: 1px solid #ddd;
        font-size: 14px;
        color: #555;
        background-color: #f4f4f4;
    }

    .submit-data {
        display: flex;
        justify-content: center;
    }

    button {
        padding: 12px 25px;
        font-size: 16px;
        background-color: #3498db;
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
</style>

<body>
    <div id="div-header"></div>

    <div class="wallpaperInicio"></div>

    <div class="div-title-site">
        <h1>Mapa Astral</h1>
    </div>

    <div class="introducao divInformacao">
        <p>O mapa astral é uma representação gráfica do céu no exato
            momento do nascimento de uma pessoa,
            local e data específicos. Ele é amplamente utilizado na astrologia como uma
            ferramenta para entender as características da personalidade,
            tendências comportamentais e possíveis caminhos de vida do indivíduo.</p>
        <br>
        <p>O mapa é composto por:</p><br>
        <ol>
            <li><b><a href="signos.php"> Os signos do zodíaco</a> </b>- representam 12 arquétipos astrológicos que indicam traços e energias.</li>
            <br>
            <li><b> Os planetas </b>- simbolizam diferentes aspectos da psique e da experiência humana (ex.: Sol - identidade; Lua - emoções; Mercúrio - comunicação).</li>
            <br>
            <li><b> As casas astrológicas </b>- são 12 divisões que correspondem a áreas específicas da vida (ex.: trabalho, relacionamentos, saúde).</li>
            <br>
            <li><b> Os aspectos </b>- ângulos formados entre planetas, que mostram como as energias interagem.</li>
        </ol>
        <br>
        <p>A combinação desses elementos é interpretada para fornecer insights únicos sobre o indivíduo, suas inclinações naturais e desafios.</p>
    </div>
    
    <div id="rodape"></div>
</body>
<script src="script.js"></script>
<script src="scriptRodape.js"></script>
<script src="scriptHeader.js"></script>

</html>